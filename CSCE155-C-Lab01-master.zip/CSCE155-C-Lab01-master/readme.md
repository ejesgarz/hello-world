# Computer Science I
## Lab 01 - Getting Started

This project is a simple "Hello World" program written in C.
To compile using gcc from the commnand line:

`gcc hello.c`

which produces an executable file named a.out, to execute it, type:

`./a.out`

This is a lab used in Computer Science I (CSCE 155E, CSCE 155H) in the [Department of Computer Science & Engineering](https://cse.unl.edu) at the [University of Nebraska-Lincoln](https://unl.edu).
