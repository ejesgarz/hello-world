/**
 * Author: Chris Bourke
 * Date: 2016/11/02
 *
 * A simple hello world program in C
 *
 */
#include<stdlib.h>
#include<stdio.h>

int main(int argc, char **argv) {

  printf("Hello World!\n");

  return 0;
}
